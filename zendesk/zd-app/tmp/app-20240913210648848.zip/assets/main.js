(function() {
  var client = ZAFClient.init();

  client.on('app.registered', function() {
    loadAssistants();
    toggleInputVisibility();  // Add this line
  });

  client.invoke('resize', { width: '100%', height: '400px' });

  var sendToDustButton = document.getElementById('sendToDustButton');
  var userInput = document.getElementById('userInput');

  sendToDustButton.addEventListener('click', handleSubmit);

  userInput.addEventListener('keydown', function(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSubmit();
    }
  });

  userInput.addEventListener('input', autoResize);

  function autoResize() {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
  }

  function handleSubmit() {
    client.get('ticket').then(function(data) {
      var ticket = data.ticket;
      sendTicketToDust(ticket);
    });
  }

  function toggleInputVisibility() {
    var selectElement = document.getElementById('assistantSelect');
    var inputWrapper = document.getElementById('inputWrapper');
    
    if (selectElement.value) {
      inputWrapper.style.display = 'block';
    } else {
      inputWrapper.style.display = 'none';
    }
  }
  

  function loadAssistants() {
    client.metadata().then(function(metadata) {
      var assistantsApiUrl = "https://dust.tt/api/v1/w/{{setting.dust_workspace_id}}/assistant/agent_configurations";

      var options = {
        url: assistantsApiUrl,
        type: 'GET',
        headers: {
          'Authorization': "Bearer {{setting.dust_api_key}}",
        },
        secure: true,
      };

      client.request(options).then(function(response) {
        console.log('API Response:', response);

        if (response && response.agentConfigurations && Array.isArray(response.agentConfigurations)) {
          var assistants = response.agentConfigurations;

          if (assistants.length === 0) {
            console.error('No assistants found in the API response');
            return;
          }

          var selectElement = document.getElementById('assistantSelect');
          assistants.forEach(function(assistant) {
            if (assistant && assistant.sId && assistant.name) {
              var option = new Option(`@${assistant.name}`, assistant.sId);
              selectElement.appendChild(option);
            }
          });

          // Initialize Select2
          $(selectElement).select2({
            placeholder: 'Select an assistant',
            allowClear: true
          }).on('change', toggleInputVisibility);

        } else {
          console.error('Unexpected API response format');
        }
      }).catch(function(error) {
        console.error('Error loading assistants:', error);
      });
    });
  }

  function sendTicketToDust(ticket) {
    var dustResponse = document.getElementById('dustResponse');
    dustResponse.style.display = 'none';
    sendToDustButton.disabled = true;
    sendToDustButton.innerHTML = '<div class="spinner"></div>';

    client.metadata().then(function(metadata) {

      var dustApiUrl = "https://dust.tt/api/v1/w/{{setting.dust_workspace_id}}/assistant/conversations";

      var selectedAssistantId = document.getElementById('assistantSelect').value;
      var userInputValue = userInput.value;

      var payload = {
        message: {
          content: `${userInputValue}\n\nZendesk Ticket #${ticket.id}\n\nSubject: ${ticket.subject}\n\nDescription: ${ticket.description}`,
          mentions: [
            {
              configurationId: selectedAssistantId
            }
          ],
          context: {
            username: "zendesk_app",
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            fullName: "Zendesk Integration",
            email: "zendesk@example.com",
            profilePictureUrl: "",
            origin: "api"
          }
        },
        title: `Zendesk Ticket #${ticket.id}`,
        visibility: "unlisted",
        blocking: true
      };

      var options = {
        url: dustApiUrl,
        type: 'POST',
        contentType: 'application/json',
        headers: {
          'Authorization': "Bearer {{setting.dust_api_key}}",
        },
        data: JSON.stringify(payload),
        secure: true,
      };

      client.request(options).then(function(response) {
        console.log('Dust conversation created:', response);
        const answer = response.conversation.content[1][0];
        const answerAgent = answer.configuration.name;
        const answerMessage = answer.content;
        console.log('Dust answer:', answerAgent, answerMessage);

        dustResponse.innerHTML = `
          <h4>@${answerAgent}:</h4>
          <pre>${answerMessage}</pre>
        `;
        dustResponse.style.display = 'block';

        client.invoke('resize', { width: '100%', height: '600px' });
      }).catch(function(error) {
        console.error('Error sending ticket to Dust:', error);
        dustResponse.innerHTML = '<p>Error sending ticket to Dust. Please try again.</p>';
        dustResponse.style.display = 'block';
      }).finally(function() {
        sendToDustButton.disabled = false;
        sendToDustButton.innerHTML = `
          <svg viewBox="0 0 24 24">
            <path d="M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"/>
          </svg>
        `;
      });
    });
  }
})();
